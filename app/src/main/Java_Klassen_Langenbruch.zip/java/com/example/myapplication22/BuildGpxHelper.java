package com.example.myapplication22;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BuildGpxHelper {

    private static final int REQUEST_CODE = 123;


    public BuildGpxHelper(Context context, String trackName, List<Coordinate> coordinates) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(context), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE);
        } else {
            writeGpxFile(context, trackName, coordinates);
        }
    }

    private void writeGpxFile(Context context, String trackName, List<Coordinate> coordinates) {
        File directory = new File(context.getExternalFilesDir(null), "Download");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        File file = new File(directory, trackName.trim()+".gpx");

        String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\" ?><gpx xmlns=\"http://www.topografix.com/GPX/1/1\" creator=\"MapSource 6.15.5\" version=\"1.1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"  xsi:schemaLocation=\"http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd\"><trk>\n";
        trackName = "<name>" + trackName + "</name><trkseg>\n";
        String segments = "";
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        for (Coordinate coordinate : coordinates) {
            segments += "<trkpt lat=\"" + coordinate.getLatitude() + "\" lon=\"" + coordinate.getLongitude() + "\"><time>" + df.format(new Date()) + "</time></trkpt>\n";
        }

        String footer = "</trkseg></trk></gpx>";

        try {
            FileWriter writer = new FileWriter(file, false);
            writer.append(header);
            writer.append(trackName);
            writer.append(segments);
            writer.append(footer);
            writer.flush();
            writer.close();
            Log.d(String.valueOf(BuildGpxHelper.class), "GPX file saved successfully at "+directory);
        } catch (IOException e) {
            Log.e(String.valueOf(BuildGpxHelper.class), "Error writing GPX file", e);
        }
    }

    private static Activity getActivity(Context context) {
        if (context instanceof Activity) {
            return (Activity) context;
        }
        return null;
    }
}
