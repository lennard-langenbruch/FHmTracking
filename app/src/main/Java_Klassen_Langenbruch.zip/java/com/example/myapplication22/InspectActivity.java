package com.example.myapplication22;

import static com.azure.android.maps.control.options.AnimationOptions.animationDuration;
import static com.azure.android.maps.control.options.AnimationOptions.animationType;
import static com.azure.android.maps.control.options.BubbleLayerOptions.bubbleColor;
import static com.azure.android.maps.control.options.BubbleLayerOptions.bubbleRadius;
import static com.azure.android.maps.control.options.BubbleLayerOptions.bubbleStrokeColor;
import static com.azure.android.maps.control.options.BubbleLayerOptions.bubbleStrokeWidth;
import static com.azure.android.maps.control.options.CameraOptions.center;
import static com.azure.android.maps.control.options.CameraOptions.zoom;
import static com.azure.android.maps.control.options.LineLayerOptions.strokeColor;
import static com.azure.android.maps.control.options.LineLayerOptions.strokeWidth;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.azure.android.maps.control.AzureMaps;
import com.azure.android.maps.control.MapControl;
import com.azure.android.maps.control.controls.ZoomControl;
import com.azure.android.maps.control.layer.BubbleLayer;
import com.azure.android.maps.control.layer.LineLayer;
import com.azure.android.maps.control.options.AnimationType;
import com.azure.android.maps.control.source.DataSource;
import com.mapbox.geojson.LineString;
import com.mapbox.geojson.Point;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class InspectActivity extends AppCompatActivity {

    static { // Azure Maps API Key
        //AzureMaps.setSubscriptionKey("");
        AzureMaps.setSubscriptionKey("5a4-bIL2yWRWmQ_dYQA_Ca6B01S1XkQyOCRgQFdF_-s");
    }
    MapControl mapControl2; // Azure Maps Object

    DatabaseHelper sqliteDatabase;

    InspectActivity instance = this;
    float distance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inspect);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        long trackid = -1;// default for not set
        if (getIntent().hasExtra("trackid")) {
            // Get the message from the intent
            trackid = getIntent().getLongExtra("trackid", -2);
        }

        sqliteDatabase = new DatabaseHelper(this);
        sqliteDatabase.getWritableDatabase(); // !!!

        Track inspectedTrack = sqliteDatabase.getSingleTrack(trackid);

        TextView header = findViewById(R.id.inspectedTrackName);
        header.setText(inspectedTrack.getName());

        //TextView distance = findViewById(R.id.distance);

        TextView elapsed = findViewById(R.id.elapsed);
        elapsed.setText("Elapsed Time: " + inspectedTrack.getElapsedTime());

        TextView textViewDateStart = findViewById(R.id.textViewDateStart);
        textViewDateStart.setText("Start Date: "+inspectedTrack.getStart());

        TextView textViewDateEnd = findViewById(R.id.textViewDateEnd);
        textViewDateEnd.setText("Finish Date: "+inspectedTrack.getFinish());


        List<Coordinate> coordinates = sqliteDatabase.getCoordinatesByTrackId(trackid); // Get your list of tracks from the database or elsewhere

        mapControl2 = findViewById(R.id.mapcontrol2);
        mapControl2.onCreate(savedInstanceState);
        int count = 0;
        mapControl2.getMapAsync(map -> {
            map.controls.add(new ZoomControl());
        });

        TableLayout tableLayout = findViewById(R.id.inspectTableLayout);
        Point previous = null;
        Location currentLocation = new Location("1");
        Location previousLocation = new Location("2");

        for (Coordinate c : coordinates) {
            final int finalCount = count;

            if(coordinates.size() > 1 && previousLocation != null) {
                currentLocation.setLongitude(Double.parseDouble(c.getLongitude()));
                currentLocation.setLatitude(Double.parseDouble(c.getLatitude()));
                distance = currentLocation.distanceTo(previousLocation);
                Log.d(String.valueOf(InspectActivity.class),""+distance);
            }
            previousLocation.setLongitude(currentLocation.getLongitude());
            previousLocation.setLatitude(currentLocation.getLatitude());

            double longitude = Double.parseDouble(c.getLongitude());
            double latitude = Double.parseDouble(c.getLatitude());

            // Place marker on azure map:
            Point finalPrevious = previous;

            mapControl2.getMapAsync(map -> { //mapControl.onReady(map -> {});
                DataSource source2 = new DataSource();
                map.sources.add(source2);
                Point p = Point.fromLngLat(longitude, latitude);

                String color = "#283593";

                if (finalPrevious != null) {
                    //Create a list of points.
                    List<Point> points = Arrays.asList(finalPrevious, p);
                    source2.add(LineString.fromLngLats(points));
                    LineLayer line = new LineLayer(source2,
                            strokeColor(color),
                            strokeWidth(5f)
                    );

                    map.layers.add(line);
                }

                source2.add(p);
                BubbleLayer bubble = new BubbleLayer(source2,
                        bubbleRadius(3f),
                        bubbleColor("#4288f7"),
                        bubbleStrokeColor(color), // #4288f7
                        bubbleStrokeWidth(5f)
                );

                //BubbleLayer layer = new BubbleLayer(source2);
                map.layers.add(bubble);
                map.setCamera(
                        center(p),
                        zoom(14),
                        animationType(AnimationType.FLY),
                        animationDuration(2000)
                );


            });

            previous = Point.fromLngLat(longitude, latitude);
        }

        inspectedTrack.setDistance(String.valueOf(distance));
        TextView textViewDistance = findViewById(R.id.distance);
        String format = inspectedTrack.getDistance() + "m";
        textViewDistance.setText("Distance: "+ format);

        ImageView listingToMainButton = findViewById(R.id.clickableImageArrow);
        listingToMainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InspectActivity.this, ListingActivity.class);
                startActivity(intent);
            }
        });

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button exportButton = findViewById(R.id.exportButton);
        exportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BuildGpxHelper buildGpx = new BuildGpxHelper(instance, inspectedTrack.getName(), coordinates);
            }
        });
    }
}