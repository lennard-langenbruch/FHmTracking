package com.example.myapplication22;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
public class GeoLocationHelper {

    private static final int REQUEST_LOCATION_PERMISSION = 1001;
    private final Context mContext;
    private final LocationManager mLocationManager;
    private final LocationListener mLocationListener;
    private Location mLastLocation;

    public double longitude;
    public double latitude;
    public float distance;

    public GeoLocationHelper(Context context) {
        mContext = context;
        mLocationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
        mLocationListener = new MyLocationListener();
        getLocation();
    }

    @SuppressLint("MissingPermission")
    public void getLocation() {
        // Check permissions and request if needed
        if (!hasLocationPermissions()) {
            requestLocationPermissions((Activity) mContext);
            return;
        }

        // Permission already granted, request a single location update
        mLocationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, mLocationListener, null);
    }

    private boolean hasLocationPermissions() {
        return ContextCompat.checkSelfPermission(mContext, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(mContext, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermissions(Activity activity) {
        // Explain to the user why the app needs the location permissions
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle("Location Permissions Required");
        builder.setMessage("Please grant location permissions to use this feature.");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Request location permissions
                ActivityCompat.requestPermissions(activity,
                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION},
                        REQUEST_LOCATION_PERMISSION);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle if the user cancels the dialog
                Log.e(String.valueOf(GeoLocationHelper.class), "User denied location permissions");
            }
        });
        builder.show();
    }

    private class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {

                mLastLocation = location;
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                Log.d(String.valueOf(GeoLocationHelper.class), "Distance:  " + longitude);
                Log.d(String.valueOf(GeoLocationHelper.class), "Location fetched: Latitude: " + latitude + ", Longitude: " + longitude);

                // Once the location is fetched, stop location updates
                mLocationManager.removeUpdates(this);

        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }
    }
}
