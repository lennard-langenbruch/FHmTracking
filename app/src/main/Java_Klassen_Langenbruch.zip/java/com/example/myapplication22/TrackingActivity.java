package com.example.myapplication22;

import static com.azure.android.maps.control.options.AnimationOptions.animationDuration;
import static com.azure.android.maps.control.options.AnimationOptions.animationType;
import static com.azure.android.maps.control.options.CameraOptions.center;
import static com.azure.android.maps.control.options.CameraOptions.zoom;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.azure.android.maps.control.AzureMaps;
import com.azure.android.maps.control.MapControl;
import com.azure.android.maps.control.controls.ZoomControl;
import com.azure.android.maps.control.layer.SymbolLayer;
import com.azure.android.maps.control.options.AnimationType;
import com.azure.android.maps.control.source.DataSource;
import com.mapbox.geojson.Point;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class TrackingActivity extends AppCompatActivity {


    static { // Azure Maps API Key
        //AzureMaps.setSubscriptionKey("");
        AzureMaps.setSubscriptionKey("5a4-bIL2yWRWmQ_dYQA_Ca6B01S1XkQyOCRgQFdF_-s");
    }

    MapControl mapControl; // Azure Maps Object
    DatabaseHelper sqliteDao; // Database Access Object
    GeoLocationHelper geoLocation;
    StopWatchHelper sw;
    long currentTackId;
    TextView textLong;
    TextView textLat;
    String longitudeString;
    String latitudeString;
    String lastSavedLongitude;
    String lastSavedLatitude;
    Date df;
    Date ds;
    String pattern = "dd.MM.yy HH:mm:ss.SSS"; // Define the desired pattern
    SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
    List<SymbolLayer> layerList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tracking);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.verticalLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sqliteDao = new DatabaseHelper(this);
        sqliteDao.getWritableDatabase(); // !!!

        currentTackId = sqliteDao.createSingleTrack("temp", "start", "0");
        String currentTrackName = "Track " + currentTackId;
        ds = new Date();

        String dateStart = dateFormat.format(ds);
        sqliteDao.updateSingleTrackById(currentTackId, currentTrackName, dateStart,null,null, null, null);

        TextView timeText = findViewById(R.id.time);
        sw = new StopWatchHelper(timeText);
        sw.start();

        geoLocation = new GeoLocationHelper(this);

            /* Initial Map Load */
            geoLocation.getLocation();
            textLong = findViewById(R.id.longitude);
            textLat = findViewById(R.id.latitude);
            mapControl = findViewById(R.id.mapcontrol);
            mapControl.onCreate(savedInstanceState);

            if(geoLocation.longitude != 0.0) {
                longitudeString = String.valueOf(geoLocation.longitude);
                latitudeString = String.valueOf(geoLocation.latitude);
                textLong.setText("Longitude: " + longitudeString);
                textLat.setText("Latitude: " + latitudeString);

                mapControl.getMapAsync(map -> { //);
                    DataSource source = new DataSource();
                    map.sources.add(source);
                    Point p = Point.fromLngLat(geoLocation.longitude, geoLocation.latitude);
                    source.add(p);
                    SymbolLayer layer = new SymbolLayer(source);
                    map.layers.add(layer);
                    layerList.add(layer);

                    map.setCamera(
                            center(p),
                            zoom(14),
                            animationType(AnimationType.FLY),
                            animationDuration(2000)
                    );

                    map.controls.add(new ZoomControl());
                });
        }

        Button stopTrackingButton = findViewById(R.id.stopTrackingButton);
        stopTrackingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sw.stop();
                sw.setRunning(false);

                df = new Date();
                //SimpleDateFormat dateFormat = new SimpleDateFormat("");
                String dateFinish = dateFormat.format(df); // dateFormat.format(d);

                long differenceInMillis = df.getTime() - ds.getTime();

                long minutes = differenceInMillis / (1000 * 60);
                long seconds = (differenceInMillis / 1000) % 60;
                long milliseconds = differenceInMillis % 1000;
                String elapsedTimeWithoutStopwatch = String.format("%02d:%02d:%02d", minutes, seconds, milliseconds);

                sqliteDao.updateSingleTrackById(currentTackId, null, null, dateFinish, elapsedTimeWithoutStopwatch, "0", null);

                Intent intent = new Intent(TrackingActivity.this, MainActivity.class);
                intent.putExtra("message", currentTrackName + " was saved successfully");
                startActivity(intent);
            }
        });

        // Start a Runnable to periodically update location
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (sw.isRunning()) {
                    updateLocation();
                    handler.postDelayed(this, 5000); // 5 seconds interval
                }
            }
        }, 1000); // Delay for the first run, 1 second
    }

    // update Location by seconds passed
    void updateLocation() {
        DataSource source = new DataSource();

        geoLocation.getLocation();
        if(geoLocation.longitude == 0.0) {
            textLong.setText("loading ... ");
            textLat.setText("loading ...");
        }


        if(geoLocation.longitude != 0.0) { // avoid first value at 0.0
        longitudeString = String.valueOf(geoLocation.longitude);
        latitudeString = String.valueOf(geoLocation.latitude);

        textLong.setText("Longitude: " + longitudeString);
        textLat.setText("Latitude: " + latitudeString);

        boolean latitudeStringChanged = !latitudeString.equals(lastSavedLatitude);
        boolean longitudeStringChanged = !longitudeString.equals(lastSavedLongitude);


        if (!latitudeStringChanged && !longitudeStringChanged) {
            Log.d(String.valueOf(GeoLocationHelper.class), "No update because location has not changed");
        }

        if (latitudeStringChanged || longitudeStringChanged) {
            // Save coordinates and link to track id
            long currentCoordinateid = sqliteDao.createSingleCoordinate(currentTackId, longitudeString, latitudeString);

            Log.d(String.valueOf(GeoLocationHelper.class), "Location/coordinate saved to database: " + longitudeString + ", " + latitudeString);

            // place marker on azure map:
            mapControl = findViewById(R.id.mapcontrol);

            mapControl.getMapAsync(map -> { //mapControl.onReady(map -> {});

                for (SymbolLayer addedLayer : layerList) {
                    map.layers.remove(addedLayer);
                }
                layerList.clear();

                map.sources.add(source);

                Point p = Point.fromLngLat(geoLocation.longitude, geoLocation.latitude);
                source.add(p);
                SymbolLayer layer = new SymbolLayer(source);
                map.layers.add(layer);
                layerList.add(layer);

                map.setCamera(
                        center(p),
                        zoom(14),
                        animationType(AnimationType.FLY),
                        animationDuration(2000)
                );

                if (map.controls.getControls() == null)
                    map.controls.add(new ZoomControl());

            });

        }

        lastSavedLongitude = longitudeString;
        lastSavedLatitude = latitudeString;

    }
    }
}
